---
name: National Infrastructure Intelligence
colors:
  surface: '#fcf9f4'
  surface-dim: '#dcdad5'
  surface-bright: '#fcf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ee'
  surface-container: '#f0ede9'
  surface-container-high: '#ebe8e3'
  surface-container-highest: '#e5e2dd'
  on-surface: '#1c1c19'
  on-surface-variant: '#594238'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f3f0eb'
  outline: '#8c7166'
  outline-variant: '#e0c0b3'
  surface-tint: '#a33e00'
  primary: '#a33e00'
  on-primary: '#ffffff'
  primary-container: '#f26a21'
  on-primary-container: '#511b00'
  inverse-primary: '#ffb596'
  secondary: '#a53c00'
  on-secondary: '#ffffff'
  secondary-container: '#ff7433'
  on-secondary-container: '#612000'
  tertiary: '#5f5e5e'
  on-tertiary: '#ffffff'
  tertiary-container: '#959393'
  on-tertiary-container: '#2c2c2c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#ffb596'
  on-primary-fixed: '#360f00'
  on-primary-fixed-variant: '#7c2e00'
  secondary-fixed: '#ffdbcd'
  secondary-fixed-dim: '#ffb598'
  on-secondary-fixed: '#360f00'
  on-secondary-fixed-variant: '#7e2c00'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474746'
  background: '#fcf9f4'
  on-background: '#1c1c19'
  surface-variant: '#e5e2dd'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Newsreader
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0em
  headline-md:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Newsreader
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Newsreader
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Newsreader
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Newsreader
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  metric-numeral:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  label-caps:
    fontFamily: Newsreader
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-regular:
    fontFamily: Newsreader
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
spacing:
  step-1: 2px
  step-2: 4px
  step-3: 8px
  step-4: 12px
  step-5: 16px
  step-6: 24px
  step-7: 32px
  step-8: 48px
  step-9: 64px
  gutter: 16px
  margin-desktop: 32px
  margin-mobile: 16px
---

## Brand & Style

This design system delivers an authoritative, institutional, and sovereign visual language engineered for national infrastructure governance, capital project tracking, and civil engineering risk oversight. It combines the austere gravitas of central bank intelligence bulletins, parliamentary white papers, and heavy civil engineering dossiers with the high-throughput efficiency of financial execution terminals.

The audience consists of cabinet ministers, infrastructure directors, chief risk officers, auditing authorities, and civil engineering project controllers. The visual presentation must project absolute neutrality, meticulous precision, and immutable credibility. 

The aesthetic is characterized by high-density structural grids, 1-pixel hairline borders, warm paper-tinted surfaces, serif-driven tabular hierarchy, and strict rectangular geometry. It completely rejects modern consumer software tropes—there are no pill-shaped badges, no diffuse drop shadows, no glassmorphism, and no decorative iconography. Every millimeter is allocated to information density, auditability, and structured command.

## Colors

The color architecture is built around an archival warm white and stone paper palette, contrasted with deep ink neutrals and an intentional industrial signal orange.

- **Canvas & Backing Surfaces**: Pure institutional white (`#FFFFFF`) serves as the base layer, while warm archival cream (`#F7F4EF`) grounds data containers, side panels, and metric wells. Additional subtle tiering uses `#FAFAF7` for elevated tables and `#F0ECE1` for table headers, active cell highlights, and toolbar strips.
- **Hairlines & Demarcations**: All structural divisions, chart grids, and containment borders are rendered in `#D9D5CE`. These lines must always remain exactly 1px solid.
- **Primary Ink & Text**: Deep carbon `#222222` is the dominant text and line-work color, providing high-contrast editorial legibility. Secondary descriptors, metadata timestamps, table column keys, and engineering unit labels use muted slate-warm stone `#66615A`.
- **Infrastructure Signal Accent**: `#F26A21` is the high-visibility focal accent, reserved strictly for critical path anomalies, budget overruns, alert callouts, active timeline progress, and state triggers. Its darker shade, `#D45512`, governs active mouse-down states and high-priority flags.

## Typography

The typographical program is unified entirely under a single classical serif family (represented in digital systems by 'Times New Roman', Times, or Newsreader). This deliberate choice rejects ubiquitous neo-grotesque sans-serifs, evoking national registries, legal land records, and physical ledger books.

All tabular data, quantitative metrics, monetary indices, and engineering coordinates must enable lining figures and tabular numeric alignment (`font-variant-numeric: tabular-nums lining-nums`). Sub-headers, column registers, and classification tiers are typeset in uppercase serif with generous tracking (+0.08em) to create clear structural demarcation in data-dense matrices.

## Layout & Spacing

The layout is governed by a strict 12-column asymmetric grid with tight 16px gutters and zero border-radius containers. It follows a multi-pane control room philosophy where vertical and horizontal dividers align flush across all panes.

- **Desktop (1280px and above)**: Full-width continuous dashboard using fixed master navigation rails (56px collapsed or 240px expanded) and a 12-column asymmetric split (e.g., 3 columns for telemetry and filters, 6 columns for central cartography/vector timeline, 3 columns for risk audit ledger). Margins are calibrated to 32px.
- **Tablet (768px - 1279px)**: Reflows to an 8-column layout. Side inspection sheets collapse into overlay drawers with 1px borders.
- **Mobile (Below 768px)**: Reflows to a single-column stacked hierarchy. Margins tighten to 16px. Multi-column metric tables shift into vertically segmented index cards or horizontal scrolling ledgers with pinned primary columns.

Compact 4px and 8px rhythmic steps dominate the internal paddings of cards, table cells, and button hit targets, ensuring high information density per square inch.

## Elevation & Depth

This design system uses a strictly flat, two-dimensional architecture rooted in low-contrast outlines and tonal surface stratification. 

- **Shadows**: Box shadows, blur filters, and diffuse drop-shadows are strictly forbidden. Depth is never communicated through faux-physical elevation.
- **Hairline Containment**: All structural separation is achieved via 1px solid borders in `#D9D5CE`. Adjacent modules touch edge-to-edge with shared borders (border-collapse paradigm).
- **Tonal Stepping**: 
  - Base canvas is `#FFFFFF`.
  - Secondary containers, filter sidebars, and structural headers sit on `#F7F4EF`.
  - Nested metric blocks and disabled rows sit on `#F0ECE1`.
  - Focused or active panels maintain a solid 1px `#222222` or `#F26A21` outline rather than a glow or elevation shadow.

## Shapes

The geometric philosophy is uncompromisingly razor-sharp:
- **0px Corner Radius**: Every interactive element, container, card, modal, badge, button, and input field must possess an absolute 0px border-radius (`border-radius: 0 !important`).
- **Precision Rectangles**: Sharp corners emphasize engineering integrity, architectural blueprints, and legal certainty.
- **Graphic Elements**: Dividers, status bars, and indicator pips use crisp geometric squares, hairline crosshairs, and rectilinear markers.

## Components

### Buttons
- **Primary Action**: Solid `#222222` fill, `#FFFFFF` text, 0px border radius, 1px solid `#222222` border. Hover transitions immediately to `#F26A21` background and border with no easing.
- **Signal / Critical Action**: Solid `#F26A21` fill, `#FFFFFF` text, 0px radius. Hover shifts to `#D45512`.
- **Secondary / Operational**: Background `#FFFFFF`, 1px solid `#D9D5CE` border, text `#222222`. Hover shifts to `#F7F4EF` with a 1px `#222222` border.
- **Typography**: Newsreader, uppercase small text (11px or 12px), tracked +0.08em, vertical padding 8px, horizontal padding 16px.

### Badges, Tags & Status Indicators
- **Form**: Rectangular status strips, never pill-shaped.
- **Active / Critical Risk**: 1px solid `#F26A21`, background `#FFFFFF` or `#F26A21` at 10% tint, text `#D45512`, uppercase 10px serif with an optional 6px solid orange square pip.
- **Normal / Certified**: 1px solid `#D9D5CE`, background `#F7F4EF`, text `#222222`.

### Data Tables & Intelligence Ledgers
- **Header Row**: Background `#F0ECE1`, 1px solid horizontal and vertical borders in `#D9D5CE`, text in `#66615A`, 11px uppercase Newsreader with tracking.
- **Body Rows**: Alternate rows can utilize `#FFFFFF` and `#FAFAF7`. Row heights fixed at dense 36px or standard 44px. All currency, station meters, percentages, and serial numbers aligned flush right in lining tabular numerals.
- **Hover**: 1px top and bottom border accentuation in `#222222` or full-row fill in `#F7F4EF`.

### Input Fields & Select Controls
- **Structure**: Rectangular box, 1px solid `#D9D5CE`, background `#FFFFFF`, text `#222222`.
- **Focus**: Instant 1px solid `#222222` border, with an inner 1px offset line if high visibility is required. No blue halo rings.
- **Labeling**: Pinned directly above the input in uppercase 11px `#66615A`.

### Checkboxes & Radio Controls
- **Checkboxes**: 14px by 14px square, 1px solid `#222222`, white background. When checked, filled with solid `#222222` featuring a sharp white checkmark or filled with `#F26A21`.
- **Radios**: Sharp square outer frame (14px) containing an internal concentric 6px solid square when selected. No circular forms.

### Metric Callout Cards
- Framed in 1px solid `#D9D5CE`, background `#F7F4EF`. Top border accented with an optional 3px solid strip of `#F26A21` for flagged assets. Number metrics typeset in 32px Newsreader semibold, paired with unit notations in 12px `#66615A`.